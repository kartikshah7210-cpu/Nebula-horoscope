# Nebula ✦ Astrology App

A mobile-first astrology app with daily horoscopes, birth chart generation, compatibility scores, and AI-powered readings via Claude.

## Features
- **Daily / Weekly / Monthly Horoscopes** for all 12 signs
- **Birth Chart Generator** — SVG wheel with planetary positions
- **Compatibility Calculator** — aspect-based scoring between two charts
- **AI Astrologer Chat** — powered by Claude (Anthropic API)
- **PWA-ready** — installable on phones

## Getting Started

### 1. Install dependencies
```bash
npm install
```

### 2. Add your Anthropic API key

Open `src/components/ChatScreen.jsx` and find the fetch call. The app uses the Anthropic API for the AI chat feature. You need to set up a backend proxy or use the API key directly for development.

> ⚠️ **Important**: Never put your API key directly in frontend code for production. Use a backend proxy or environment variable approach.

For quick local testing, you can use the Claude.ai artifact environment which handles authentication automatically.

### 3. Run locally
```bash
npm run dev
```
App runs at `http://localhost:5173`

### 4. Build for production
```bash
npm run build
```
Output goes to `dist/` folder.

---

## Deploy to Vercel (Free)

1. Push this folder to a GitHub repo
2. Go to [vercel.com](https://vercel.com) → New Project → Import your repo
3. Click Deploy — done!

Your app will be live at `your-project.vercel.app`

## Deploy to Netlify (Free)

1. Go to [netlify.com](https://netlify.com) → Add new site → Deploy manually
2. Drag and drop the `dist/` folder after running `npm run build`

---

## Make it a Phone App (PWA)

The `public/manifest.json` is already set up. Once deployed:
- On iPhone: Open in Safari → Share → Add to Home Screen
- On Android: Open in Chrome → three dots menu → Add to Home Screen

---

## Project Structure

```
nebula/
├── index.html              # Entry point
├── vite.config.js          # Vite config
├── public/
│   ├── manifest.json       # PWA manifest
│   └── star.svg            # App icon
└── src/
    ├── main.jsx            # React root
    ├── App.jsx             # Main layout + navigation
    ├── index.css           # Global styles + CSS variables
    ├── data/
    │   └── astrology.js    # All sign data, horoscopes, calculations
    └── components/
        ├── StarBackground.jsx   # Animated star field
        ├── HoroscopeScreen.jsx  # Daily/weekly/monthly horoscopes
        ├── ChartScreen.jsx      # Birth chart form + display
        ├── ChartWheel.jsx       # Canvas-based chart wheel
        ├── CompatScreen.jsx     # Compatibility calculator
        └── ChatScreen.jsx       # AI astrologer chat
```

---

## Customization Ideas
- Add real ephemeris data using `astronomia` npm package for accurate planet positions
- Connect a location autocomplete API for birth place lookup
- Add user accounts with Supabase (free tier) to save charts
- Add push notifications for daily horoscopes
