import { useState, useRef, useEffect } from 'react'

const QUICK_QUESTIONS = [
  "What's my life purpose?",
  "Love forecast this month?",
  "Explain my rising sign",
  "Best career for my chart?",
]

const SYSTEM_PROMPT = `You are Nebula, a wise and poetic AI astrologer. You speak with warmth, depth, and mystical insight — like a trusted oracle who genuinely cares. Keep responses concise (2–4 sentences), evocative, and personally meaningful. You believe in astrology as a symbolic language for self-understanding. Do not use bullet points or lists — speak in flowing, lyrical prose. Weave in planetary and zodiacal references naturally. Avoid generic advice; be specific and illuminating.`

export default function ChatScreen() {
  const [messages, setMessages] = useState([
    { role: 'ai', text: 'Welcome, seeker. I am Nebula — your guide through the cosmic map of your life. Ask me about your birth chart, relationships, life purpose, or simply what the stars hold for you today.' }
  ])
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const historyRef = useRef(null)

  useEffect(() => {
    if (historyRef.current) {
      historyRef.current.scrollTop = historyRef.current.scrollHeight
    }
  }, [messages, loading])

  const send = async (text) => {
    const q = (text || input).trim()
    if (!q || loading) return
    setInput('')
    const next = [...messages, { role: 'user', text: q }]
    setMessages(next)
    setLoading(true)

    const apiMessages = next
      .filter(m => m.role === 'user' || m.role === 'ai')
      .map(m => ({ role: m.role === 'ai' ? 'assistant' : 'user', content: m.text }))

    try {
      const res = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: 'claude-sonnet-4-20250514',
          max_tokens: 1000,
          system: SYSTEM_PROMPT,
          messages: apiMessages,
        }),
      })
      const data = await res.json()
      const reply = data.content?.[0]?.text || 'The cosmic signal wavered. Ask again and the stars will answer.'
      setMessages(m => [...m, { role: 'ai', text: reply }])
    } catch {
      setMessages(m => [...m, { role: 'ai', text: 'The celestial connection faded. Please try again in a moment.' }])
    }
    setLoading(false)
  }

  return (
    <div style={{ padding: '0 16px 16px', flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      {/* Quick questions */}
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginBottom: 10 }}>
        {QUICK_QUESTIONS.map(q => (
          <button key={q} onClick={() => send(q)} style={{
            padding: '5px 12px', background: 'rgba(255,255,255,0.04)',
            border: '0.5px solid rgba(255,255,255,0.1)', borderRadius: 20,
            color: 'rgba(245,243,238,0.5)', fontSize: 12, fontStyle: 'italic',
            fontFamily: 'var(--font-serif)', cursor: 'pointer', transition: 'all 0.2s',
          }}>
            {q}
          </button>
        ))}
      </div>

      {/* Chat history */}
      <div ref={historyRef} style={{
        flex: 1, overflowY: 'auto', display: 'flex',
        flexDirection: 'column', gap: 10, marginBottom: 12,
        minHeight: 0,
      }}>
        {messages.map((m, i) => (
          <div key={i} style={{ display: 'flex', gap: 10, flexDirection: m.role === 'user' ? 'row-reverse' : 'row' }}>
            <div style={{
              width: 28, height: 28, borderRadius: '50%', flexShrink: 0,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontSize: 12,
              background: m.role === 'ai' ? 'rgba(107,95,166,0.22)' : 'rgba(201,168,76,0.13)',
              border: `0.5px solid ${m.role === 'ai' ? 'rgba(107,95,166,0.4)' : 'rgba(201,168,76,0.3)'}`,
            }}>
              {m.role === 'ai' ? '✦' : '☽'}
            </div>
            <div style={{
              maxWidth: '82%', padding: '10px 13px', borderRadius: 12,
              fontSize: 14, lineHeight: 1.68,
              background: m.role === 'ai' ? 'rgba(255,255,255,0.05)' : 'rgba(201,168,76,0.1)',
              border: `0.5px solid ${m.role === 'ai' ? 'rgba(255,255,255,0.08)' : 'rgba(201,168,76,0.2)'}`,
              color: m.role === 'ai' ? 'rgba(245,243,238,0.85)' : 'var(--gold2)',
              textAlign: m.role === 'user' ? 'right' : 'left',
            }}>
              {m.text}
            </div>
          </div>
        ))}

        {loading && (
          <div style={{ display: 'flex', gap: 10 }}>
            <div style={{
              width: 28, height: 28, borderRadius: '50%', flexShrink: 0,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontSize: 12, background: 'rgba(107,95,166,0.22)',
              border: '0.5px solid rgba(107,95,166,0.4)',
            }}>✦</div>
            <div style={{
              padding: '12px 16px', borderRadius: 12,
              background: 'rgba(255,255,255,0.05)', border: '0.5px solid rgba(255,255,255,0.08)',
              display: 'flex', gap: 5, alignItems: 'center',
            }}>
              {[0, 0.2, 0.4].map((d, i) => (
                <div key={i} style={{
                  width: 5, height: 5, borderRadius: '50%',
                  background: 'rgba(245,243,238,0.4)',
                  animation: `bounce 1.2s ease-in-out ${d}s infinite`,
                }} />
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Input */}
      <div style={{ display: 'flex', gap: 8, flexShrink: 0 }}>
        <input
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && send()}
          placeholder="Ask the stars anything…"
          style={{
            flex: 1, background: 'rgba(255,255,255,0.05)',
            border: '0.5px solid rgba(255,255,255,0.12)', borderRadius: 10,
            padding: '9px 12px', color: 'var(--mist)',
            fontFamily: 'var(--font-serif)', fontSize: 15, outline: 'none',
          }}
        />
        <button onClick={() => send()} style={{
          padding: '9px 14px', background: 'rgba(201,168,76,0.13)',
          border: '0.5px solid var(--gold)', borderRadius: 10,
          color: 'var(--gold2)', fontSize: 14, cursor: 'pointer',
          transition: 'all 0.2s',
        }}>✦</button>
      </div>
    </div>
  )
}
