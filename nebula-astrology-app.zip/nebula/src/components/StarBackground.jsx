import { useMemo } from 'react'

export default function StarBackground() {
  const stars = useMemo(() => Array.from({ length: 70 }, (_, i) => ({
    id: i,
    size: Math.random() * 2 + 0.5,
    top: Math.random() * 100,
    left: Math.random() * 100,
    delay: Math.random() * 5,
    duration: 2 + Math.random() * 3,
  })), [])

  return (
    <div style={{ position: 'absolute', inset: 0, overflow: 'hidden', pointerEvents: 'none', zIndex: 0 }}>
      {stars.map(s => (
        <div key={s.id} style={{
          position: 'absolute',
          width: s.size,
          height: s.size,
          borderRadius: '50%',
          background: 'white',
          top: `${s.top}%`,
          left: `${s.left}%`,
          animation: `twinkle ${s.duration}s ease-in-out ${s.delay}s infinite`,
        }} />
      ))}
    </div>
  )
}
