import { useState } from 'react'
import { SIGNS, GLYPHS, DATES, ELEMENTS, SIGN_COLORS, HOROSCOPES } from '../data/astrology'

const s = {
  screen: { padding: '0 16px 20px', overflowY: 'auto', flex: 1 },
  signScroll: { display: 'flex', gap: 6, overflowX: 'auto', paddingBottom: 8, marginBottom: 16, scrollbarWidth: 'none' },
  pill: (active, color) => ({
    flexShrink: 0, padding: '5px 12px', borderRadius: 20,
    border: `0.5px solid ${active ? color : 'rgba(255,255,255,0.14)'}`,
    background: active ? `${color}22` : 'rgba(255,255,255,0.04)',
    color: active ? color : 'rgba(245,243,238,0.55)',
    fontFamily: 'var(--font-mono)', fontSize: 10, cursor: 'pointer',
    transition: 'all 0.2s', whiteSpace: 'nowrap',
  }),
  card: { background: 'rgba(255,255,255,0.04)', border: '0.5px solid rgba(255,255,255,0.1)', borderRadius: 14, padding: 20, marginBottom: 12 },
  header: { display: 'flex', alignItems: 'center', gap: 14, marginBottom: 14 },
  glyph: { fontSize: 40, lineHeight: 1 },
  signName: { fontSize: 26, fontWeight: 300, letterSpacing: '0.05em' },
  signDates: { fontFamily: 'var(--font-mono)', fontSize: 10, color: 'rgba(245,243,238,0.4)', marginTop: 2 },
  tabs: { display: 'flex', gap: 8, marginBottom: 14 },
  tab: (active) => ({
    padding: '4px 14px', borderRadius: 20, cursor: 'pointer',
    border: `0.5px solid ${active ? 'rgba(107,95,166,0.7)' : 'rgba(255,255,255,0.1)'}`,
    background: active ? 'rgba(107,95,166,0.15)' : 'none',
    color: active ? '#a89fdc' : 'rgba(245,243,238,0.4)',
    fontFamily: 'var(--font-mono)', fontSize: 10, transition: 'all 0.2s',
  }),
  text: { fontSize: 16, lineHeight: 1.9, color: 'rgba(245,243,238,0.82)', fontWeight: 300, fontStyle: 'italic' },
  energyGrid: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginTop: 16 },
  energyLabel: { fontFamily: 'var(--font-mono)', fontSize: 9, color: 'rgba(245,243,238,0.4)', letterSpacing: '0.08em', marginBottom: 4 },
  energyTrack: { height: 3, background: 'rgba(255,255,255,0.07)', borderRadius: 2, overflow: 'hidden' },
}

const energyVal = (sign, period, offset) =>
  35 + Math.abs((sign * 17 + offset + (period === 'daily' ? 0 : period === 'weekly' ? 30 : 55)) % 58)

export default function HoroscopeScreen() {
  const [sign, setSign] = useState(0)
  const [period, setPeriod] = useState('daily')
  const color = SIGN_COLORS[sign]

  const energies = [
    { label: 'LOVE',   val: energyVal(sign, period, 0) },
    { label: 'CAREER', val: energyVal(sign, period, 13) },
    { label: 'HEALTH', val: energyVal(sign, period, 27) },
    { label: 'SPIRIT', val: energyVal(sign, period, 41) },
  ]

  return (
    <div style={s.screen}>
      <div style={s.signScroll}>
        {SIGNS.map((name, i) => (
          <button key={name} style={s.pill(i === sign, SIGN_COLORS[i])} onClick={() => setSign(i)}>
            {GLYPHS[i]} {name}
          </button>
        ))}
      </div>

      <div style={s.card} className="fade-up">
        <div style={s.header}>
          <div style={{ ...s.glyph, color }}>{GLYPHS[sign]}</div>
          <div>
            <div style={{ ...s.signName, color }}>{SIGNS[sign]}</div>
            <div style={s.signDates}>{DATES[sign]} · {ELEMENTS[sign]}</div>
          </div>
        </div>

        <div style={s.tabs}>
          {['daily', 'weekly', 'monthly'].map(p => (
            <button key={p} style={s.tab(period === p)} onClick={() => setPeriod(p)}>
              {p.charAt(0).toUpperCase() + p.slice(1)}
            </button>
          ))}
        </div>

        <div
          style={s.text}
          dangerouslySetInnerHTML={{ __html: HOROSCOPES[period][sign] }}
        />

        <div style={s.energyGrid}>
          {energies.map(e => (
            <div key={e.label}>
              <div style={s.energyLabel}>{e.label} · {e.val}%</div>
              <div style={s.energyTrack}>
                <div style={{ height: '100%', borderRadius: 2, width: `${e.val}%`, background: color, transition: 'width 0.6s ease' }} />
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
