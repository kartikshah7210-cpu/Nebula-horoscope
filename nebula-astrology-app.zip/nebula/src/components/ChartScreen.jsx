import { useState } from 'react'
import { SIGNS, GLYPHS, CHART_INTERPRETATIONS, calcPlanets, getSunSign } from '../data/astrology'
import ChartWheel from './ChartWheel'

const inp = {
  width: '100%', background: 'rgba(255,255,255,0.05)',
  border: '0.5px solid rgba(255,255,255,0.12)', borderRadius: 8,
  padding: '8px 10px', color: 'var(--mist)',
  fontFamily: 'var(--font-mono)', fontSize: 11, outline: 'none',
}

export default function ChartScreen() {
  const [date, setDate] = useState('1990-06-15')
  const [time, setTime] = useState('14:30')
  const [place, setPlace] = useState('Mumbai, India')
  const [planets, setPlanets] = useState(null)
  const [rising, setRising] = useState(0)
  const [seed, setSeed] = useState(0)

  const generate = () => {
    const result = calcPlanets(date, time)
    const d = new Date(date + 'T' + time)
    const s = d.getFullYear() * 365 + d.getMonth() * 31 + d.getDate()
    const r = (getSunSign(date) + 1 + Math.floor(s / 7) % 5) % 12
    setPlanets(result)
    setRising(r)
    setSeed(s)
  }

  return (
    <div style={{ padding: '0 16px 20px', overflowY: 'auto', flex: 1 }}>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 12 }}>
        <Field label="BIRTH DATE"><input type="date" value={date} onChange={e => setDate(e.target.value)} style={inp} /></Field>
        <Field label="BIRTH TIME"><input type="time" value={time} onChange={e => setTime(e.target.value)} style={inp} /></Field>
        <Field label="BIRTH PLACE" full>
          <input type="text" value={place} onChange={e => setPlace(e.target.value)} placeholder="City, Country" style={inp} />
        </Field>
      </div>

      <button onClick={generate} style={{
        width: '100%', padding: '11px', marginBottom: 16,
        background: 'rgba(201,168,76,0.13)', border: '0.5px solid var(--gold)',
        borderRadius: 10, color: 'var(--gold2)',
        fontFamily: 'var(--font-serif)', fontSize: 16, letterSpacing: '0.1em',
        cursor: 'pointer', transition: 'all 0.2s',
      }}>
        ✦ Generate Birth Chart ✦
      </button>

      {planets && (
        <div className="fade-up">
          <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 16 }}>
            <ChartWheel planets={planets} rising={rising} size={230} />
          </div>

          <SectionLabel>PLANETARY POSITIONS</SectionLabel>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 8, marginBottom: 14 }}>
            {planets.map(p => (
              <div key={p.name} style={{
                background: 'rgba(255,255,255,0.04)', border: '0.5px solid rgba(255,255,255,0.08)',
                borderRadius: 10, padding: '10px 8px', textAlign: 'center',
              }}>
                <div style={{ fontSize: 18, marginBottom: 3 }}>{p.symbol}</div>
                <div style={{ fontFamily: 'var(--font-mono)', fontSize: 8, color: 'rgba(245,243,238,0.38)', letterSpacing: '0.08em', marginBottom: 3 }}>{p.name}</div>
                <div style={{ fontSize: 13, color: 'var(--gold2)', fontWeight: 300 }}>{GLYPHS[p.sign]} {SIGNS[p.sign]}</div>
              </div>
            ))}
          </div>

          <SectionLabel>INTERPRETATION</SectionLabel>
          <div style={{
            background: 'rgba(255,255,255,0.04)', border: '0.5px solid rgba(255,255,255,0.08)',
            borderRadius: 12, padding: 16,
            fontSize: 15, lineHeight: 1.85, color: 'rgba(245,243,238,0.78)',
            fontStyle: 'italic', fontWeight: 300,
          }}>
            {CHART_INTERPRETATIONS[seed % CHART_INTERPRETATIONS.length]}
          </div>
        </div>
      )}
    </div>
  )
}

function Field({ label, children, full }) {
  return (
    <div style={{ gridColumn: full ? 'span 2' : undefined }}>
      <div style={{ fontFamily: 'var(--font-mono)', fontSize: 9, letterSpacing: '0.1em', color: 'rgba(245,243,238,0.38)', marginBottom: 5 }}>{label}</div>
      {children}
    </div>
  )
}

function SectionLabel({ children }) {
  return (
    <div style={{ fontFamily: 'var(--font-mono)', fontSize: 9, letterSpacing: '0.15em', color: 'rgba(245,243,238,0.3)', margin: '12px 0 8px' }}>
      {children}
    </div>
  )
}
