import { useState } from 'react'
import { SIGNS, GLYPHS, aspectScore } from '../data/astrology'

function SignSelect({ id, value, onChange }) {
  return (
    <select value={value} onChange={e => onChange(Number(e.target.value))} style={{
      width: '100%', background: 'rgba(255,255,255,0.05)',
      border: '0.5px solid rgba(255,255,255,0.12)', borderRadius: 8,
      padding: '7px 8px', color: 'var(--mist)',
      fontFamily: 'var(--font-mono)', fontSize: 10, outline: 'none',
    }}>
      {SIGNS.map((s, i) => <option key={s} value={i} style={{ background: '#1a1730' }}>{GLYPHS[i]} {s}</option>)}
    </select>
  )
}

function Field({ label, children }) {
  return (
    <div>
      <div style={{ fontFamily: 'var(--font-mono)', fontSize: 9, letterSpacing: '0.08em', color: 'rgba(245,243,238,0.35)', marginBottom: 4 }}>{label}</div>
      {children}
    </div>
  )
}

const COMPAT_DESCS = [
  [90, '#e8c97a', 'A rare cosmic alignment. Your souls recognized each other long before your minds did. This connection carries the weight of destiny and the lightness of true joy.'],
  [78, '#89a8d0', 'The stars weave your stories together with uncommon grace. Depth, passion, and genuine understanding flow between your charts with beautiful ease.'],
  [65, '#c4a2d0', 'Complementary forces create dynamic tension and growth. You challenge and inspire each other — this connection transforms both people profoundly.'],
  [50, '#8aab7a', 'Complex aspects create a relationship that requires consciousness and care. The growth is real, and so is the work — both are worth it.'],
  [0,  '#a8a098', 'Your charts create fascinating friction. Differences become the greatest teachers when approached with curiosity rather than resistance.'],
]

export default function CompatScreen() {
  const [p1, setP1] = useState({ sun: 0, moon: 3, rising: 1, venus: 2 })
  const [p2, setP2] = useState({ sun: 4, moon: 7, rising: 5, venus: 6 })
  const [result, setResult] = useState(null)

  const calc = () => {
    const sunSun   = aspectScore(p1.sun, p2.sun)
    const moonMoon = aspectScore(p1.moon, p2.moon)
    const venVen   = aspectScore(p1.venus, p2.venus)
    const risRis   = aspectScore(p1.rising, p2.rising)
    const sunMoon  = Math.round((aspectScore(p1.sun, p2.moon) + aspectScore(p2.sun, p1.moon)) / 2)
    const overall  = Math.round(sunSun * 0.25 + moonMoon * 0.3 + venVen * 0.25 + risRis * 0.1 + sunMoon * 0.1)
    const desc = COMPAT_DESCS.find(d => overall >= d[0])
    setResult({ overall, sunSun, moonMoon, venVen, risRis, sunMoon, color: desc[1], desc: desc[2] })
  }

  const bars = result ? [
    { label: 'SUN–SUN',    val: result.sunSun,   color: '#e8993a' },
    { label: 'MOON–MOON',  val: result.moonMoon, color: '#89a8d0' },
    { label: 'VENUS–VENUS',val: result.venVen,   color: '#c9a84c' },
    { label: 'SUN–MOON',   val: result.sunMoon,  color: '#a89fdc' },
    { label: 'RISING',     val: result.risRis,   color: '#5b99c2' },
  ] : []

  return (
    <div style={{ padding: '0 16px 20px', overflowY: 'auto', flex: 1 }}>
      {[
        { label: 'PERSON 1', state: p1, setState: setP1 },
        { label: 'PERSON 2', state: p2, setState: setP2 },
      ].map(({ label, state, setState }) => (
        <div key={label} style={{
          background: 'rgba(255,255,255,0.03)', border: '0.5px solid rgba(255,255,255,0.08)',
          borderRadius: 12, padding: 14, marginBottom: 10,
        }}>
          <div style={{ fontFamily: 'var(--font-mono)', fontSize: 9, letterSpacing: '0.1em', color: 'rgba(245,243,238,0.3)', marginBottom: 10 }}>{label}</div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
            <Field label="SUN SIGN"><SignSelect value={state.sun} onChange={v => setState(s => ({ ...s, sun: v }))} /></Field>
            <Field label="MOON SIGN"><SignSelect value={state.moon} onChange={v => setState(s => ({ ...s, moon: v }))} /></Field>
            <Field label="RISING SIGN"><SignSelect value={state.rising} onChange={v => setState(s => ({ ...s, rising: v }))} /></Field>
            <Field label="VENUS SIGN"><SignSelect value={state.venus} onChange={v => setState(s => ({ ...s, venus: v }))} /></Field>
          </div>
        </div>
      ))}

      <button onClick={calc} style={{
        width: '100%', padding: 11, marginBottom: 14,
        background: 'rgba(201,168,76,0.13)', border: '0.5px solid var(--gold)',
        borderRadius: 10, color: 'var(--gold2)',
        fontFamily: 'var(--font-serif)', fontSize: 16, letterSpacing: '0.1em',
        cursor: 'pointer', transition: 'all 0.2s',
      }}>
        ✦ Calculate Compatibility ✦
      </button>

      {result && (
        <div className="fade-up">
          <div style={{
            background: 'rgba(255,255,255,0.04)', border: '0.5px solid rgba(255,255,255,0.09)',
            borderRadius: 14, padding: 20, textAlign: 'center', marginBottom: 12,
          }}>
            <div style={{ fontSize: 72, fontWeight: 300, letterSpacing: -2, lineHeight: 1, color: result.color }}>
              {result.overall}
            </div>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'rgba(245,243,238,0.38)', letterSpacing: '0.1em', marginTop: 4 }}>
              COSMIC COMPATIBILITY
            </div>
            <div style={{ fontSize: 15, fontStyle: 'italic', color: 'rgba(245,243,238,0.7)', marginTop: 12, lineHeight: 1.75 }}>
              {result.desc}
            </div>
          </div>

          <div style={{ fontFamily: 'var(--font-mono)', fontSize: 9, letterSpacing: '0.15em', color: 'rgba(245,243,238,0.3)', marginBottom: 10 }}>
            COMPATIBILITY BREAKDOWN
          </div>
          {bars.map(b => (
            <div key={b.label} style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 9 }}>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: 9, color: 'rgba(245,243,238,0.38)', width: 72, flexShrink: 0 }}>{b.label}</div>
              <div style={{ flex: 1, height: 4, background: 'rgba(255,255,255,0.07)', borderRadius: 2, overflow: 'hidden' }}>
                <div style={{ height: '100%', borderRadius: 2, width: `${b.val}%`, background: b.color, transition: 'width 0.8s ease' }} />
              </div>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: 9, color: 'rgba(245,243,238,0.45)', width: 28, textAlign: 'right' }}>{b.val}%</div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
