import { useEffect, useRef } from 'react'
import { GLYPHS, SIGN_COLORS } from '../data/astrology'

export default function ChartWheel({ planets, rising, size = 220 }) {
  const canvasRef = useRef(null)

  useEffect(() => {
    if (!planets || planets.length === 0) return
    const canvas = canvasRef.current
    const ctx = canvas.getContext('2d')
    const cx = size / 2, cy = size / 2
    const r = size / 2 - 8

    ctx.clearRect(0, 0, size, size)

    // Outer ring
    ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2)
    ctx.strokeStyle = 'rgba(201,168,76,0.35)'; ctx.lineWidth = 1; ctx.stroke()

    // Sign band fill
    for (let i = 0; i < 12; i++) {
      const a1 = ((i * 30 - 90 + rising * 30) * Math.PI) / 180
      const a2 = (((i + 1) * 30 - 90 + rising * 30) * Math.PI) / 180
      ctx.beginPath()
      ctx.moveTo(cx + r * 0.73 * Math.cos(a1), cy + r * 0.73 * Math.sin(a1))
      ctx.arc(cx, cy, r, a1, a2)
      ctx.arc(cx, cy, r * 0.73, a2, a1, true)
      ctx.closePath()
      ctx.fillStyle = `${SIGN_COLORS[i]}11`
      ctx.fill()
    }

    // Middle ring
    ctx.beginPath(); ctx.arc(cx, cy, r * 0.73, 0, Math.PI * 2)
    ctx.strokeStyle = 'rgba(255,255,255,0.09)'; ctx.lineWidth = 0.5; ctx.stroke()

    // Inner ring
    ctx.beginPath(); ctx.arc(cx, cy, r * 0.38, 0, Math.PI * 2)
    ctx.strokeStyle = 'rgba(255,255,255,0.07)'; ctx.lineWidth = 0.5; ctx.stroke()

    // House lines
    for (let i = 0; i < 12; i++) {
      const angle = ((i * 30 - 90 + rising * 30) * Math.PI) / 180
      ctx.beginPath()
      ctx.moveTo(cx + r * 0.38 * Math.cos(angle), cy + r * 0.38 * Math.sin(angle))
      ctx.lineTo(cx + r * Math.cos(angle), cy + r * Math.sin(angle))
      ctx.strokeStyle = i % 3 === 0 ? 'rgba(201,168,76,0.28)' : 'rgba(255,255,255,0.07)'
      ctx.lineWidth = i % 3 === 0 ? 1 : 0.5
      ctx.stroke()
    }

    // Sign glyphs in outer band
    ctx.font = `${Math.round(size * 0.042)}px serif`
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle'
    for (let i = 0; i < 12; i++) {
      const angle = (((i + 0.5) * 30 - 90 + rising * 30) * Math.PI) / 180
      const rx = cx + r * 0.865 * Math.cos(angle)
      const ry = cy + r * 0.865 * Math.sin(angle)
      ctx.fillStyle = SIGN_COLORS[i]
      ctx.fillText(GLYPHS[i], rx, ry)
    }

    // Aspect lines between planets
    const planetPositions = planets.map((p, idx) => {
      const baseAngle = ((p.sign + 0.5) * 30 - 90 + rising * 30) * Math.PI / 180
      const offset = ((idx % 3) - 1) * 0.09
      const a = baseAngle + offset
      const pr = r * 0.56
      return { x: cx + pr * Math.cos(a), y: cy + pr * Math.sin(a), sign: p.sign }
    })

    // Draw subtle aspect lines
    for (let i = 0; i < planetPositions.length; i++) {
      for (let j = i + 1; j < planetPositions.length; j++) {
        const diff = Math.abs(planets[i].sign - planets[j].sign) % 12
        const d = diff > 6 ? 12 - diff : diff
        if (d === 4 || d === 8 || d === 3 || d === 9) {
          ctx.beginPath()
          ctx.moveTo(planetPositions[i].x, planetPositions[i].y)
          ctx.lineTo(planetPositions[j].x, planetPositions[j].y)
          ctx.strokeStyle = d === 4 || d === 8 ? 'rgba(201,168,76,0.12)' : 'rgba(107,95,166,0.12)'
          ctx.lineWidth = 0.5
          ctx.stroke()
        }
      }
    }

    // Planet dots
    planets.forEach((p, idx) => {
      const baseAngle = ((p.sign + 0.5) * 30 - 90 + rising * 30) * Math.PI / 180
      const offset = ((idx % 3) - 1) * 0.09
      const a = baseAngle + offset
      const pr = r * 0.56
      const px = cx + pr * Math.cos(a)
      const py = cy + pr * Math.sin(a)
      ctx.beginPath(); ctx.arc(px, py, 7, 0, Math.PI * 2)
      ctx.fillStyle = 'rgba(14,12,26,0.95)'; ctx.fill()
      ctx.strokeStyle = p.color || 'rgba(201,168,76,0.6)'; ctx.lineWidth = 1; ctx.stroke()
      ctx.font = `${Math.round(size * 0.038)}px serif`
      ctx.fillStyle = 'rgba(245,243,238,0.92)'
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle'
      ctx.fillText(p.symbol, px, py)
    })

    // ASC label
    const ascAngle = ((-90 + rising * 30) * Math.PI) / 180
    ctx.font = `500 ${Math.round(size * 0.034)}px monospace`
    ctx.fillStyle = 'rgba(201,168,76,0.85)'
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle'
    ctx.fillText('ASC', cx + r * 1.09 * Math.cos(ascAngle), cy + r * 1.09 * Math.sin(ascAngle))

  }, [planets, rising, size])

  return <canvas ref={canvasRef} width={size} height={size} style={{ display: 'block' }} />
}
