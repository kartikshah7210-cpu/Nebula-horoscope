export const SIGNS = [
  'Aries','Taurus','Gemini','Cancer','Leo','Virgo',
  'Libra','Scorpio','Sagittarius','Capricorn','Aquarius','Pisces'
]

export const GLYPHS = ['♈','♉','♊','♋','♌','♍','♎','♏','♐','♑','♒','♓']

export const DATES = [
  'Mar 21–Apr 19','Apr 20–May 20','May 21–Jun 20','Jun 21–Jul 22',
  'Jul 23–Aug 22','Aug 23–Sep 22','Sep 23–Oct 22','Oct 23–Nov 21',
  'Nov 22–Dec 21','Dec 22–Jan 19','Jan 20–Feb 18','Feb 19–Mar 20'
]

export const ELEMENTS = [
  'Fire','Earth','Air','Water','Fire','Earth',
  'Air','Water','Fire','Earth','Air','Water'
]

export const MODALITIES = [
  'Cardinal','Fixed','Mutable','Cardinal','Fixed','Mutable',
  'Cardinal','Fixed','Mutable','Cardinal','Fixed','Mutable'
]

export const RULERS = [
  'Mars','Venus','Mercury','Moon','Sun','Mercury',
  'Venus','Pluto','Jupiter','Saturn','Uranus','Neptune'
]

export const SIGN_COLORS = [
  '#e06b4a','#7ab06b','#89a8d0','#5b99c2','#e8993a','#a8b85a',
  '#c4a2d0','#7766bb','#e8844a','#8aab7a','#6bc2d4','#8899d0'
]

export const PLANETS = [
  { name: 'SUN',     symbol: '☉', color: '#e8993a' },
  { name: 'MOON',    symbol: '☽', color: '#89a8d0' },
  { name: 'MERCURY', symbol: '☿', color: '#a8b85a' },
  { name: 'VENUS',   symbol: '♀', color: '#c4a2d0' },
  { name: 'MARS',    symbol: '♂', color: '#e06b4a' },
  { name: 'JUPITER', symbol: '♃', color: '#e8c97a' },
  { name: 'SATURN',  symbol: '♄', color: '#8aab7a' },
  { name: 'URANUS',  symbol: '⛢', color: '#6bc2d4' },
  { name: 'NEPTUNE', symbol: '♆', color: '#8899d0' },
]

export const HOROSCOPES = {
  daily: [
    "The cosmos align in your favor today. <strong>Mars energizes your ambitions</strong>, pushing you toward bold decisions. A conversation this afternoon could open unexpected doors — listen more than you speak.",
    "Venus graces your second house, bringing financial intuition. <strong>Trust your instincts about value</strong> — both material and emotional. An old friendship may resurface with surprising depth.",
    "Mercury, your ruler, sparks intellectual fireworks. <strong>Ideas flow like water today</strong> — capture them before they vanish. A sibling or neighbor brings news that reshapes your perspective.",
    "The Moon in your sign amplifies your sensitivity. <strong>Your emotional intelligence is your superpower</strong> today. Home matters deserve attention; a small act of nurturing creates lasting warmth.",
    "The Sun illuminates your natural charisma. <strong>You are magnetic today</strong> — step into the spotlight without hesitation. Creative projects begun now carry extraordinary potential.",
    "Practical Mercury sharpens your analytical mind. <strong>Details others miss become your advantage.</strong> Health and routine deserve attention — a small discipline yields remarkable results.",
    "Venus blesses your partnerships. <strong>Harmony flows easily today</strong> — lean into collaboration. An aesthetic decision you've been postponing calls for your refined eye.",
    "Pluto whispers transformation. <strong>Something beneath the surface is ready to emerge.</strong> Depth and intensity draw others to you; use this power with wisdom and care.",
    "Jupiter expands your horizons gloriously. <strong>Possibility feels limitless today</strong> — because it is. A foreign connection or philosophical insight brings unexpected joy.",
    "Saturn rewards your discipline. <strong>Slow and steady builds the empire you deserve.</strong> Professional recognition may come from an unexpected quarter — remain patient.",
    "Uranus sparks brilliant innovation. <strong>Your most unusual idea is your best one.</strong> Collective energy fuels your vision; community is your greatest asset today.",
    "Neptune deepens your psychic sensitivity. <strong>Dreams carry coded messages today</strong> — pay attention. Creative and spiritual work reaches extraordinary heights."
  ],
  weekly: [
    "This week, Mars activates your first house with fierce determination. <strong>Obstacles that seemed permanent begin to dissolve.</strong> Wednesday carries peak energy — schedule your most important meetings then.",
    "Venus lingers in a favorable trine to your sun, making this week ideal for financial conversations. <strong>What you value and what you earn begin to align.</strong> Mid-week brings a beautiful encounter with beauty itself.",
    "Mercury stations direct in your third house — communication flows freely after weeks of static. <strong>Send the message, make the call, speak the truth.</strong> Thursday's lunar energy supports short journeys.",
    "The full moon in your opposite sign illuminates relationship patterns. <strong>What you've been tolerating becomes undeniable.</strong> This week demands emotional honesty. By Sunday, clarity replaces confusion.",
    "The sun moves through your fifth house, blessing romance, creativity, and play. <strong>This is a week for joy — schedule it deliberately.</strong> A creative project reaches a significant milestone.",
    "Mercury in your sixth house creates the ideal week for systems and health. <strong>Redesign your routines and they will serve you for months.</strong> A health insight arrives Wednesday — take it seriously.",
    "Venus crosses your seventh house threshold, making this one of your most socially magnetic weeks. <strong>Partnerships of all kinds flourish.</strong> A beautiful collaboration is possible — say yes.",
    "Pluto intensifies an already deep week. <strong>Transformation isn't coming — it's already happening.</strong> Financial and intimate matters require your full presence. Surrender brings power.",
    "Jupiter in your ninth house makes this week philosophical and expansive. <strong>A belief you've held loosely becomes a conviction.</strong> Travel, even mentally through books, opens something profound.",
    "Saturn tests your long-term structures this week. <strong>What is truly built to last will pass the exam.</strong> Professional matters require patience and precision. Friday rewards consistency.",
    "Uranus shakes your eleventh house, electrifying your social world. <strong>A revolutionary friendship begins to matter deeply.</strong> Technology brings unexpected connection. Your future vision crystallizes.",
    "Neptune deepens your twelfth house mysticism. <strong>This week, solitude is sacred, not lonely.</strong> Dreams and intuition speak loudly — keep a journal nearby. A karmic pattern completes itself quietly."
  ],
  monthly: [
    "Mars transits your chart with rare force this month. <strong>Initiative taken in the first two weeks has lasting impact.</strong> The new moon plants seeds of identity — who do you want to become? By month's end, answers arrive.",
    "Venus spends three weeks gracing your sector of wealth and values. <strong>Financial decisions made now carry wisdom.</strong> A significant purchase or investment aligns with your deeper values. Love and money intertwine.",
    "Mercury's journey through three houses activates communication, home, and creativity in sequence. <strong>This month, your voice finds its fullest expression.</strong> A writing or speaking project reaches an audience.",
    "The full moon in your sign this month is your cosmic reset. <strong>Emotions that have been submerged finally surface — let them.</strong> Family dynamics shift. By month's end, you know what home truly means.",
    "The sun blazes through your sign for most of the month. <strong>This is your season — own it without apology.</strong> Creative work reaches new heights. Romance intensifies. Leadership opportunities multiply.",
    "Six planets activate your work and health sectors in rotation. <strong>This month transforms your daily life permanently.</strong> A health practice begins. A working relationship deepens into genuine respect.",
    "Venus rules your month, making beauty, justice, and partnership your central themes. <strong>A relationship enters a new chapter.</strong> The middle of the month brings breathtaking clarity about what you truly want.",
    "Pluto and Mars meet in your chart, creating transformative intensity. <strong>This is a month for death and rebirth.</strong> Release what no longer serves with courage and trust the phoenix process completely.",
    "Jupiter's expansive energy touches nearly every area of your life. <strong>This is one of your most fortunate months in years.</strong> Say yes to opportunities that feel slightly too large. Growth is inevitable.",
    "Saturn and the sun collaborate in your favor. <strong>Hard work done in previous months pays dividends now.</strong> Professional elevation is possible — position yourself to receive it. Patience transforms to momentum.",
    "Uranus makes its annual station in your sign, accelerating evolution. <strong>This month, you outgrow something you thought was permanent.</strong> Technology, community, and future vision all illuminate simultaneously.",
    "Neptune conjuncts your sun, dissolving boundaries between self and cosmos. <strong>This month, creativity and spirituality merge.</strong> Artistic work channels something beyond your conscious mind. A dream holds profound meaning."
  ]
}

export const CHART_INTERPRETATIONS = [
  "Your chart reveals a soul drawn to transformation and depth. With your placements, there is a natural tension between your desire for security and your hunger for evolution — and it is precisely this tension that fuels your greatest growth. The cosmos shaped you for a journey of becoming, not arriving.",
  "A chart of remarkable balance and beauty. Your Sun and Moon work in harmony, suggesting an integrated emotional and conscious self. Your rising sign adds a layer of mystique that draws people in before they understand why. You are more powerful than you know.",
  "The planetary concentrations in your chart point to a focused, purposeful lifetime. You came here with specific gifts to develop and offer. Your houses of creativity and communication are particularly activated — your voice matters more than you realize.",
  "Multiple planetary aspects create a rich inner life that may not always be visible to others. You process deeply before expressing. When you do share, the words carry weight accumulated from much silent contemplation. This is your gift.",
  "Your chart shows exceptional sensitivity paired with formidable strength — a combination that, when balanced, makes you an extraordinary force for healing and creation in the world around you.",
]

export function getSunSign(dateStr) {
  const d = new Date(dateStr)
  const m = d.getMonth() + 1
  const day = d.getDate()
  if ((m === 3 && day >= 21) || (m === 4 && day <= 19)) return 0
  if ((m === 4 && day >= 20) || (m === 5 && day <= 20)) return 1
  if ((m === 5 && day >= 21) || (m === 6 && day <= 20)) return 2
  if ((m === 6 && day >= 21) || (m === 7 && day <= 22)) return 3
  if ((m === 7 && day >= 23) || (m === 8 && day <= 22)) return 4
  if ((m === 8 && day >= 23) || (m === 9 && day <= 22)) return 5
  if ((m === 9 && day >= 23) || (m === 10 && day <= 22)) return 6
  if ((m === 10 && day >= 23) || (m === 11 && day <= 21)) return 7
  if ((m === 11 && day >= 22) || (m === 12 && day <= 21)) return 8
  if ((m === 12 && day >= 22) || (m === 1 && day <= 19)) return 9
  if ((m === 1 && day >= 20) || (m === 2 && day <= 18)) return 10
  return 11
}

export function calcPlanets(dateStr, timeStr) {
  const d = new Date(dateStr + 'T' + (timeStr || '12:00'))
  const seed = d.getFullYear() * 365 + d.getMonth() * 31 + d.getDate()
  const hour = d.getHours() + d.getMinutes() / 60
  const sun = getSunSign(dateStr)
  return [
    { ...PLANETS[0], sign: sun },
    { ...PLANETS[1], sign: (sun + 3 + (seed % 7)) % 12 },
    { ...PLANETS[2], sign: ((sun + (seed % 3 === 0 ? -1 : seed % 3)) % 12 + 12) % 12 },
    { ...PLANETS[3], sign: (sun + 1 + (seed % 2)) % 12 },
    { ...PLANETS[4], sign: (sun + 4 + (seed % 5)) % 12 },
    { ...PLANETS[5], sign: seed % 12 },
    { ...PLANETS[6], sign: (seed * 2) % 12 },
    { ...PLANETS[7], sign: (seed * 3) % 12 },
    { ...PLANETS[8], sign: (seed * 7) % 12 },
  ]
}

export function aspectScore(a, b) {
  const diff = Math.abs(a - b) % 12
  const d = diff > 6 ? 12 - diff : diff
  if (d === 0) return 95
  if (d === 4 || d === 8) return 88
  if (d === 3 || d === 9) return 78
  if (d === 2 || d === 10) return 72
  if (d === 6) return 55
  if (d === 1 || d === 11) return 65
  return 70
}
