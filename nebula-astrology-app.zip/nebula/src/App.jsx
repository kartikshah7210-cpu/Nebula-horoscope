import { useState } from 'react'
import StarBackground from './components/StarBackground'
import HoroscopeScreen from './components/HoroscopeScreen'
import ChartScreen from './components/ChartScreen'
import CompatScreen from './components/CompatScreen'
import ChatScreen from './components/ChatScreen'

const TABS = [
  { id: 'horoscope', label: 'DAILY' },
  { id: 'chart',     label: 'CHART' },
  { id: 'compat',    label: 'COMPAT' },
  { id: 'chat',      label: 'AI CHAT' },
]

export default function App() {
  const [tab, setTab] = useState('horoscope')

  const today = new Date().toLocaleDateString('en-US', {
    weekday: 'short', month: 'short', day: 'numeric'
  }).toUpperCase()

  return (
    <div style={{
      width: '100%', maxWidth: 420,
      height: '100dvh', maxHeight: 780,
      background: 'var(--ink)',
      borderRadius: window.innerWidth > 420 ? 24 : 0,
      overflow: 'hidden',
      display: 'flex', flexDirection: 'column',
      position: 'relative',
      boxShadow: '0 0 80px rgba(0,0,0,0.6)',
    }}>
      <StarBackground />

      {/* Top bar */}
      <div style={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '16px 20px 12px',
        borderBottom: '0.5px solid rgba(255,255,255,0.07)',
        position: 'relative', zIndex: 2, flexShrink: 0,
      }}>
        <div style={{ fontFamily: 'var(--font-serif)', fontSize: 22, letterSpacing: '0.1em', color: 'var(--gold2)', fontWeight: 300 }}>
          <em>Nebula</em> ✦
        </div>
        <div style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'rgba(245,243,238,0.38)', letterSpacing: '0.05em' }}>
          {today}
        </div>
      </div>

      {/* Nav */}
      <div style={{
        display: 'flex', gap: 2,
        background: 'rgba(255,255,255,0.04)', borderRadius: 10, padding: 3,
        margin: '10px 14px 6px',
        position: 'relative', zIndex: 2, flexShrink: 0,
      }}>
        {TABS.map(t => (
          <button key={t.id} onClick={() => setTab(t.id)} style={{
            flex: 1, padding: '7px 4px',
            background: tab === t.id ? 'rgba(201,168,76,0.17)' : 'none',
            border: 'none',
            borderRadius: 7,
            color: tab === t.id ? 'var(--gold2)' : 'rgba(245,243,238,0.42)',
            fontFamily: 'var(--font-mono)', fontSize: 10, letterSpacing: '0.05em',
            cursor: 'pointer', transition: 'all 0.2s',
          }}>
            {t.label}
          </button>
        ))}
      </div>

      {/* Screens */}
      <div style={{ flex: 1, overflow: 'hidden', display: 'flex', flexDirection: 'column', position: 'relative', zIndex: 1 }}>
        {tab === 'horoscope' && <HoroscopeScreen />}
        {tab === 'chart'     && <ChartScreen />}
        {tab === 'compat'    && <CompatScreen />}
        {tab === 'chat'      && <ChatScreen />}
      </div>
    </div>
  )
}
